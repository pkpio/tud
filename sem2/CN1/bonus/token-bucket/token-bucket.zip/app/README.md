# token-bucket
A visualization of the Token Bucket 

# How to run
Open ```index.html``` in any of the popular Web browsers or refer to a 
live demo at http://praveen.xyz/demos/token-bucket/
