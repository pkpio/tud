package de.tu_darmstadt.se.healthtracker.model;

public final class Category {
	
	private /*@ spec_public @*/ int id;

	private String name;
	
	public int getId() {
		return id;
	}
	
	public String getName() { 
		return name;
	}

}
