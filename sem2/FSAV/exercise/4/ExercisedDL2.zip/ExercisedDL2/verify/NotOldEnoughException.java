public class NotOldEnoughException extends Exception {
}