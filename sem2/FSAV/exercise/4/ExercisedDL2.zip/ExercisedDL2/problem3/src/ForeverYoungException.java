public class ForeverYoungException extends RuntimeException {
}