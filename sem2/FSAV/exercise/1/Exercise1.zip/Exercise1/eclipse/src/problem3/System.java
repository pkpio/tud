package problem3;

public class System {


	public static void arraycopy(int[] src, int srcPos, int[] dest, int destPos, int length) {
		// here should be an implementation
	}
	
}
