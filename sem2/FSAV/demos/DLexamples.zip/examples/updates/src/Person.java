public class Person {
    private int age;
}