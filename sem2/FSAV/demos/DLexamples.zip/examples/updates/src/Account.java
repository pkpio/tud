public class Account {
    private int nr;
    private int balance;
}