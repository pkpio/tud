public final class Flags {

    public static boolean finallyExecuted; 

}