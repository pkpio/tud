public class TCFDemo {

    private final static NullPointerException NPE = new NullPointerException();

    public static int tcf(int a) {
	Flags.finallyExecuted = false;
	try {
	    if ( a == 0 ) {
		throw NPE;
	    }
	} catch (NullPointerException npe) {
            return 0;
	} finally {
	    Flags.finallyExecuted = true;
	}
	return 1;
    }


}