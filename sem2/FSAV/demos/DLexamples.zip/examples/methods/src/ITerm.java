/**
 * Interface to be implemented by classes representing a term
 */
public interface ITerm {

    /**
     * return sthe top level operator 
     */
    IOperator op();
    
    /**
     * returns the term's arity
     */
    int arity();

    /**
     * returns the <tt>n</tt>-th sub term
     */
    ITerm sub(int n);

}