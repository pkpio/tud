/**
 * Interface to be implemented by classes representing an operator.
 */
public interface IOperator {

}