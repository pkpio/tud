public class Account {

    private int nr;

}