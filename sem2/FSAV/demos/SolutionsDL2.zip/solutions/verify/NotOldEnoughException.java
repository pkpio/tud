package verify;

public class NotOldEnoughException extends Exception {
}