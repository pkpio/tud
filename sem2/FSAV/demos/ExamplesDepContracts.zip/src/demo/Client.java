package demo;

public class Client {
    public int x;
    
    /*@ public invariant \disjoint(list.footprint, this.*); @*/ 
    /*@ public invariant \invariant_for(list); @*/
    public List list;
    
    /*@ normal_behaviour
      @ ensures x == \old(x + 1);
      @ assignable x;
      @*/
    void m() {
        x++;
    }
    
    
}
