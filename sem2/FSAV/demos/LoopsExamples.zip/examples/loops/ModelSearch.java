public class ModelSearch {
    /*@ public normal_behavior
      @ requires i >= 0 && j >= 0 && i<a.length && j<a.length;
      @ ensures a[i] == \old(a[j]) && a[j] == \old(a[i]);
      @ assignable a[i], a[j];
      @*/
    public static void swap(int[] a, int i, int j) {   
	if (a[i] > a[j]) { 
	    int h = a[i];
	    a[i] = a[j];
	    a[j] = h;
	}
    }
}
