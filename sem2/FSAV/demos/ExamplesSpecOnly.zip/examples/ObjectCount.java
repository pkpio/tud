
public class ObjectCount {
	//@ ghost int createdObjects = 0;
	
	
	/*@ public normal_behavior
	  @ requires n >= 0;
	  @ ensures createdObjects <= \old(createdObjects) + ((n + 2) / 3);
	  @*/
	public void consume(int n) {
		/*@ loop_invariant 
		  @    i>= 0 && i <= n &&
		  @ 	   createdObjects == \old(createdObjects) + ((i+2)/3);
		  @ assignable createdObjects; 		 
		  @ decreases n - i; 
		  @*/
		for (int i = 0; i<n; i++) {
			if (i % 3 == 0) {
				ObjectCount o = new ObjectCount();
				//@ set createdObjects = createdObjects + 1;
				; // <-- technical trick if set assignment at end of a block/method
			}
		}		
	}
	
}
