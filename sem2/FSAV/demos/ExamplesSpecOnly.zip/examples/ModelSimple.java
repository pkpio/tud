// This class is just used to demo
// the represents axiom and the calculus rule
// the classes and specifications do not make much sense otherwise

public interface ModelSimple {
    //@ protected instance model int value;
	
	/*@ public normal_behavior
	  @ ensures value == value; 
	  @*/
	public /*@ pure @*/ int get();
}

class ModelSimpleA implements ModelSimple {
	
	boolean b;
	//@ represents value \such_that value == (b ? 1 : 0);

	public /*@ pure @*/ int get() {
		if (b) {
			return 1;
		} else {
			return 0;
		}
	}

}

class ModelSimpleB implements ModelSimple {
	
	protected int min;
	//@ represents value \such_that value >= min;
	
	public /*@ pure @*/ int get() {
		return min;
	}

}

class ModelSimpleC extends ModelSimpleB {
	
	//@ public invariant max >= min;
	protected int max;
	//@ represents value \such_that value >= min && value <= max;  //overwrites previous represents

	public /*@ pure @*/ int get() {
		return (min + max) / 2;
	}

}
