public final class Decimal {

	public static final short PRECISION = (short) 1000;
	/*@ spec_public @*/ private short intPart = (short) 0;

	//@ public invariant decPart >= 0 && decPart < PRECISION;
	/*@ spec_public @*/ private short decPart = (short) 0;


	/*@ public normal_behavior
	  @ requires \invariant_for(other);
	  @ ensures intPart * PRECISION + decPart == 
	  @      \old( (intPart + other.intPart) * PRECISION + (decPart + other.decPart));
	  @ assignable decPart, intPart;
	  @*/
	public void add(Decimal other) {
		intPart += other.intPart;
		if ((decPart + other.decPart) / PRECISION != 0) {
			intPart++;
		}
		decPart = (short) ((decPart + other.decPart) % PRECISION);
	}
	
	
	/*@ public normal_behavior
	  @ requires \invariant_for(other);
	  @ ensures intPart == \old(other.intPart + intPart) + 
	  @ 	      (\old(decPart + other.decPart) >= PRECISION ? 1 : 0);
	  @ ensures decPart == \old( (decPart + other.decPart) % PRECISION); 
	  @ assignable decPart, intPart;
	  @*/
	public void add2(Decimal other) {
		intPart += other.intPart;
		if ((decPart + other.decPart) / PRECISION != 0) {
			intPart++;
		}
		decPart = (short) ((decPart + other.decPart) % PRECISION);
	}
}

