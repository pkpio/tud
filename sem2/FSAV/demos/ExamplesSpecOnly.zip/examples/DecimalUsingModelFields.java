public final class DecimalUsingModelFields {

	public static final short PRECISION = (short) 1000;
	/*@ spec_public @*/ private short intPart = (short) 0;

	//@ public invariant decPart >= 0 && decPart < PRECISION;
	/*@ spec_public @*/ private short decPart = (short) 0;
	
	//@ public model short value;
	//@ represents value = intPart * PRECISION + decPart;  
	

	/*@ public normal_behavior
	  @ requires \invariant_for(other);
	  @ ensures value == 
	  @      \old( value + other.value );
	  @ assignable decPart, intPart;
	  @*/
	public void add(DecimalUsingModelFields other) {
		intPart += other.intPart;
		if ((decPart + other.decPart) / PRECISION != 0) {
			intPart++;
		}
		decPart = (short) ((decPart + other.decPart) % PRECISION);
	}
}

