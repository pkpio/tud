package frame;

public class Client {
    
    //@ public invariant \invariant_for(a) && \invariant_for(b);
    private /*@ spec_public @*/ List a, b;
    
    /*@ public normal_behavior
      @ requires a != b;
      @ requires \disjoint(a.footprint, b.footprint);
      @ ensures b.size() == \old(b.size());
      @*/
    public void m() {
        a.add(123);
    }
    
}
