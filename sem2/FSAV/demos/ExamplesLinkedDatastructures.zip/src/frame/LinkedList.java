package frame;

public class LinkedList implements List {

    protected /*@ nullable @*/ LinkedList tail;
    protected int elem;
    
    //@ private represents theList = tail == null ? \seq_singleton(elem) : tail.theList;
    //@ private represents footprint = \reachLocs(tail, this);
    
    public LinkedList(int elem) {
        this.elem = elem;
    }

    public void add (int elem) {
        LinkedList tmp = new LinkedList(elem);
        tmp.tail = this.tail;
        this.tail = tmp;
    }

    public int size () {
        return tail == null ? 1 : 1 + tail.size();
    }

    public int get (int idx) {
        return idx == 0 ? elem : tail.get(idx);
    }

}
