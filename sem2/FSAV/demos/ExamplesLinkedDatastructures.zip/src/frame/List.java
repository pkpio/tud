package frame;

public interface List {
    //@ public instance model \locset footprint;
    //@ public accessible footprint: footprint;
    
    //@ public instance model \seq theList;
    //@ public accessible theList: footprint;
    
    //@ public instance invariant size() >= 0;
    //@ public accessible \inv: footprint;
    
    /*@ public normal_behavior
      @ ensures theList == \seq_concat(\seq_singleton(elem),
      @                                \old(theList));
      @ ensures \new_elems_fresh(footprint);                               
      @ assignable footprint;
      @*/
    public void add (int elem);

    /*@ public normal_behavior
      @ ensures \result == theList.length;
      @ accessible footprint;
      @*/
    public /*@ pure @*/ int size ();

    /*@ public normal_behavior
      @ requires 0 <= idx && idx < size();
      @ ensures \result == (int)theList[idx];
      @ accessible footprint;
      @*/
    public /*@ pure @*/ int get (int idx);
}
