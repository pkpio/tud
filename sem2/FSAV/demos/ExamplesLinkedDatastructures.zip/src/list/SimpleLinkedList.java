package list;

public class SimpleLinkedList {

    private /*@ spec_public @*/ int content;
    
    //@ public invariant size >= 1;
    private /*@ spec_public @*/ int size;

    /*@ public invariant (\exists SimpleLinkedList e; 
      @    (\reach(this.next, this, e, size-1) && e.next == null));
      @*/
    // Questions:
    //    Why does the above mean that next is not null 
    //      for any element in the list except for the last?
    //    Why does it as it is written also imply that the 
    //      list is acyclic?
    private /*@ spec_public nullable @*/ SimpleLinkedList next;

    public SimpleLinkedList(int content) {
        this.content = content;
    }
    
    /*@ public normal_behavior
      @ requires i>=0 && i < size;
      @ ensures (\exists SimpleLinkedList e;
      @     (\reach(this.next, this, e, i) && e.content == \result));
      @ assignable \nothing;
      @*/
    public int get(int i) {
        if (i<0 || i>=size) {
            throw new IndexOutOfBoundsException();
        }
        
        SimpleLinkedList current = this;
        /*@ loop_invariant \reach(this.next, this, current, \old(i) - i) && i>=0 && i <= \old(i);
          @ assignable \nothing;
          @ decreases i;
          @*/
        while (i != 0) {
            current = current.next;
            i--;
        }
        return current.content;
    }

}
