package list;

public class SimpleLinkedListSeq {

    private /*@ spec_public @*/ int storedValue;
    private /*@ spec_public @*/ int size;

    
    //@ model \seq content;
    /*@ represents content \such_that 
      @   (\forall SimpleLinkedListSeq l;
      @     (\forall int i; i>=0 && i<size; 
      @        \reach(this.next, this, l, i) ==>
      @                    content[i] == l.storedValue)); 
      @*/
        
    /*@ public invariant (\exists SimpleLinkedList e; 
      @     (\reach(this.next, this, e, size-1) && e.next == null));
      @*/
    // Questions:
    //    Why does the above ensure that next is not null for any element of the list except for the last?
    //    Why does it, as it is written, also imply that the list is acyclic?
    private /*@ spec_public nullable @*/ SimpleLinkedListSeq next;


    public SimpleLinkedListSeq(int storedValue) {
        this.storedValue = storedValue;
    }
    
    /*@ public normal_behavior
      @ ensures content == \seq_concat(\old(content), \dl_array2seq(v));
      @*/
    public void append(int[] v) {
         // ... to be implemented
    }
    

    /*@ public normal_behavior
      @ requires i>=0 && i < size;
      @ ensures \result == content[i];
      @ assignable \nothing;
      @*/
    public int get(int i) {
        if (i<0 || i>=size) {
            throw new IndexOutOfBoundsException();
        }
        
        SimpleLinkedListSeq current = this;
        /*@ loop_invariant \reach(this.next, this, current, \old(i) - i) && i>=0 && i <= \old(i);
          @ assignable \nothing;
          @ decreases i;
          @*/
        while (i != 0) {
            current = current.next;
            i--;
        }
        return current.storedValue;
    }

}
