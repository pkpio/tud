package list;

public class SimpleLinkedListRec {

    private /*@ spec_public @*/ int content;
    private /*@ spec_public @*/ int size;

    //@ public invariant size > 1 <==> next != null;
    //@ public invariant size >= 1;
   
    // both invariant s below also ensure acyclicity; 
    // why? How to state explicitly acyclicity?
    //@ public invariant size > 1 ==> next.size == size - 1;   
    //@ public invariant \invariant_for(next); 
    private /*@ spec_public nullable @*/ SimpleLinkedListRec next;


    public SimpleLinkedListRec(int content) {
        this.content = content;
    }

    /*@ public normal_behavior
      @ requires i>=0 && i < size;
      @ ensures \result == (i > 0 ? next.get(i - 1) : this.content);
      @ assignable \nothing;
      @*/
    public int get(int i) {
        if (i<0 || i>=size) {
            throw new IndexOutOfBoundsException();
        }
        SimpleLinkedListRec current = this;
        /*@ loop_invariant 
          @    current.content == this.get(\old(i) - i) 
          @    && i>=0 && i<=\old(i); 
          @ assignable \nothing;
          @ decreases i;
          @*/
        while (i != 0) {
            current = current.next;
            i--;
        }
        return current.content;
    }

}
