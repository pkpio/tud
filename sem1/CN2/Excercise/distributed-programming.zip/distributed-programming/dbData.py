import MySQLdb, sys
class database:
 
 
  dbUser = "mensa"
  dbHost = "localhost"
  dbPassword = "TKwVWs2rJw6TAERt"
  dbDatabase = "mensa"
  def connect(self):
    self.db = MySQLdb.connect(host=self.dbHost, user=self.dbUser, passwd=self.dbPassword,db=self.dbDatabase,charset='utf8')
    self.cursor = self.db.cursor()
  def addFood(self, date, mensa, food):
    self.cursor.execute("""SELECT `MID` from `mensa`.`Mensen` where `mensa`='%s';""" % (mensa))
    self.db.commit()
    if int(self.cursor.rowcount)>0:
      mid = self.cursor.fetchone()[0]
    else: 
      self.cursor.execute("""INSERT INTO `mensa`.`Mensen` (`Mensa`) VALUES ('%s');"""% (mensa))
      mid = self.cursor.lastrowid
      self.db.commit()
    self.cursor.execute("""SELECT `FID` from `mensa`.`Food` where `Name`='%s';""" % (food))
    if int(self.cursor.rowcount)>0:
      fid = self.cursor.fetchone()[0]
    else:
      self.cursor.execute("""INSERT INTO `mensa`.`Food` (`Name`,`Up`,`Down`) VALUES ('%s','%d','%d');"""%(food,0,0))
      fid = self.cursor.lastrowid
      self.db.commit()
    self.cursor.execute("""INSERT INTO `mensa`.`Plan` (`Date`,`MID`,`FID`) VALUES ('%s','%d','%d');"""%(date,mid,fid))
    self.db.commit()

  def getTodaysMenus(self):
    self.cursor.execute("""SELECT `Mensen`.`Mensa`, `Food`.`FID`, `Food`.`Name`, `Food`.`Up`, `Food`.`Down` FROM `Plan` , `Mensen` , `Food` WHERE `Plan`.`Date` = CURDATE( ) AND `Mensen`.`MID` = `Plan`.`MID` AND `Food`.`FID` = `Plan`.`FID`""")
    self.db.commit()
    reload(sys)
    sys.setdefaultencoding("utf-8")
    for row in self.cursor.fetchall():
      x = [row[0],str(row[1]),row[2],str(row[3]),str(row[4])]
#      print x
      yield x

  def getComments(self,fid):
    self.cursor.execute("""SELECT `Comment` FROM `Comments` WHERE `FID`='%d'"""%(fid))
    self.db.commit()
    for row in self.cursor.fetchall():
      yield row[0]

  def addComment(self,fid,comment):
    self.cursor.execute("""INSERT INTO `mensa`.`Comments` (`FID`, `Comment`) VALUES ('%d','%s');"""%(fid,comment))
    self.db.commit()

  def upvote(self,fid):
    self.cursor.execute("""UPDATE `Food` SET `Up` = `Up`+1 WHERE `FID`='%d'"""%(fid))
    self.db.commit()

  def downvote(self,fid):
    self.cursor.execute("""UPDATE `Food` SET `Down` = `Down`+1 WHERE `FID`='%d'"""%(fid))
    self.db.commit()
