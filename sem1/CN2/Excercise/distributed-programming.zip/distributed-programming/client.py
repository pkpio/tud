from suds.client import Client
client = Client('http://test09.kom.e-technik.tu-darmstadt.de:1140/?wsdl')
# get all menus
menus = client.service.getTodaysMenus()
print menus
# add comment to menu 38
client.service.addComment(38,"fands ganz in ordnung")
# get comments on menu 38
comments = client.service.getComments(38)
print comments
# up and downvote
client.service.upvote(38)
client.service.downvote(39)
# and show changes
menus = client.service.getTodaysMenus()
print menus
