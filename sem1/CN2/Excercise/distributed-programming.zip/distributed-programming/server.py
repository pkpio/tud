from spyne import Application, rpc, ServiceBase, Iterable, Integer, Unicode
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
import urllib2
import dbData

class MensaRating(ServiceBase):
  def __init__(self):
    self.db = dbData.database()
    self.db.connect()

  @rpc(_returns=Iterable(Iterable(Unicode)))
  def getTodaysMenus(ctx):
    """Lists the today available menus
    @return an array of arrays that contain the following values: Mensa, Food ID (fid), name of the food, upvotes, downvotes
    """
    logging.info("getting the meals")
    db = dbData.database()
    db.connect()
    return db.getTodaysMenus()
        
  @rpc(Integer, _returns=Iterable(Unicode))
  def getComments(ctx, fid):
    """Gives you all the comments to the meal with the given Food ID
    @param fid the id of the food
    @return an array of the comments
    """
    logging.info("requesting comments of %d"%(fid))
    db = dbData.database()
    db.connect()
    return db.getComments(fid)

  @rpc(Integer, Unicode)
  def addComment(ctx, fid, comment):
    """ads a comment to a meal
    @param fid the id of the food
    """
    logging.info('adding comment "%s" to %d'%(comment, fid))
    db = dbData.database()
    db.connect()
    db.addComment(fid, comment)

  @rpc(Integer)
  def upvote(ctx,fid):
    """Upvotes a meal
    @param fid the id of the food
    """
    logging.info("upvoting: %d"%(fid))
    db = dbData.database()
    db.connect()
    db.upvote(fid)

  @rpc(Integer)
  def downvote(ctx,fid):
    """Downvotes a meal
    @param fid the id of the food
    """
    logging.info("downvoting: %d"%(fid))
    db = dbData.database()
    db.connect()
    db.downvote(fid)


application = Application([MensaRating], 'de.tu-darmstadt.e-technik.kom.kn2.mensa-soap-webservice',
        in_protocol=Soap11(validator='lxml'),
        out_protocol=Soap11()
    )

wsgi_application = WsgiApplication(application)


if __name__ == '__main__':
    import logging

    from wsgiref.simple_server import make_server

    logging.basicConfig(level=logging.DEBUG)
    logging.getLogger('spyne.protocol.xml').setLevel(logging.DEBUG)

    logging.info("listening to http://0.0.0.0:1140")
    logging.info("wsdl is at: http://localhost:1140/?wsdl")
    server = make_server('0.0.0.0', 1140, wsgi_application)
    server.serve_forever()

