import re, sys, json, MySQLdb
from datetime import datetime
from HTMLParser import HTMLParser
import dbData
def htmlToDictionary(html):
  startTag = '<table border="1" class="spk_table">'
  endTag = '</table>'
  startpos = html.find(startTag)
  endpos = html.find(endTag,startpos)
  html = html[startpos:endpos+len(endTag)]
  cell = re.compile(r'<t[dh][^<]*>(?:(?!<t[hd]).)*</t[dh]>')
  allCells = re.findall(cell,html)
  parser = HTMLParser()
  for place, item in enumerate(allCells):
    noTags = re.sub('(<.*?>|\\xc2\\xa0)', '', item)
    allCells[place] = parser.unescape(noTags)
  retArray = {}
  retValue = ""
  for x in range(1,2):
    mensen = {}
    tmpMensa = [allCells[x+2]]
    tmpMensaName = allCells[2]
    for y in range(2,len(allCells)/2):
      if allCells[y*2]!="":
        mensen[tmpMensaName] = tmpMensa
        tmpMensa = [allCells[x+2*y]]
        tmpMensaName = allCells[2*y]
      else:
        if allCells[x+2*y]!="":
          tmpMensa.append(allCells[x+2*y])
    mensen[tmpMensaName] = tmpMensa
    dateregex = re.compile(r'\d{2}.\d{2}.\d{4}')
    datestr = re.findall(dateregex,allCells[x])[0]
    retArray[datestr] = mensen
  return retArray

def putIntoDB(mealPlan):
  database = dbData.database()
  database.connect()
  for date,mensen in mealPlan.iteritems():
    date_object = datetime.strptime(date, '%d.%m.%Y')
    date = date_object.strftime("%Y-%m-%d")
    for name, meals in mensen.iteritems():
      for meal in meals:
        print ("adding %s %s %s"%(date,name,meal))
        database.addFood(date,name,meal)  


def htmlToText(html):
	allMensen = htmlToDictionary(html)
	retValue = ""
	for date, mensen in allMensen.iteritems():
		retValue += date+":\n"
		for name, meals in mensen.iteritems():
			retValue += "\t"+name+":\n"
			for meal in meals:
				retValue += "\t\t"+meal+"\n"
	return retValue
import urllib2
reload(sys)
sys.setdefaultencoding("utf-8")
response = urllib2.urlopen('http://www.stwda.de/components/com_spk/spk_Stadtmitte_print.php')
html = response.read()
print htmlToText(html)
putIntoDB(htmlToDictionary(html))
