#!/usr/bin/python
import urllib2
from http_exercise_utils import *
reload(sys)
sys.setdefaultencoding("utf-8")
response = urllib2.urlopen('http://www.studentenwerkdarmstadt.de/index.php/de/essen-und-trinken/speisekarten/stadtmitte?ansicht=week')
html = response.read()
print htmlToText(html)
