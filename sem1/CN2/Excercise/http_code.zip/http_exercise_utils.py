import re
import sys
import json
try:
	from HTMLParser import HTMLParser
except:
	from html.parser import HTMLParser
	
from collections import OrderedDict
from datetime import datetime

# Takes the HTML Code of the Mensa page and transforms it into a Dictionary, the base 
# for all the other methods
def htmlToDictionary(html):
	#only this complicated as we didn't want to depend on non standard libraries
	#extract the table from the page
	startag = '<table border="1" class="spk_table">'
	endtag = '</table>'
	startpos = html.find(startag)
	endpos = html.find(endtag,startpos)
	html = html[startpos:endpos+len(endtag)]
	#extract all the cells
	cell = re.compile(r'<td[^>]*>.*</td>')
	allCells = re.findall(cell, html)
	parser = HTMLParser()
	#delete all the html from all the cells
	for place, item in enumerate(allCells):
		noTags = re.sub('(<.*?>|\\xc2\\xa0)', '', item)
		allCells[place] = parser.unescape(noTags)
	#build retValue
	retArray = {}
	retValue = ""
	for x in range(1,6):
		mensen = {}
		tmpMensa = [allCells[x+6]]
		tmpMensaName = allCells[6]
		for y in range(2,len(allCells)/6):
			if allCells[y*6]!="":
				mensen[tmpMensaName] = tmpMensa
				tmpMensa = [allCells[x+6*y]]
				tmpMensaName = allCells[6*y]
			else:
				if allCells[x+6*y]!="":
					tmpMensa.append(allCells[x+6*y])
		mensen[tmpMensaName] = tmpMensa
		retArray[allCells[x]] = mensen
	return OrderedDict(sorted(retArray.items(), key=lambda t: t[0]))

# Takes the HTML Code of the Mensa page and transforms it into prety printable
# text
def htmlToText(html):
	allMensen = htmlToDictionary(html)
	retValue = ""
	for date, mensen in allMensen.iteritems():
		retValue += date+":\n"
		for name, meals in mensen.iteritems():
			retValue += "\t"+name+":\n"
			for meal in meals:
				retValue += "\t\t"+meal+"\n"
	return retValue
	
# Takes the HTML Code of the Mensa page and transforms it into an ical file.
# It contains only the real necessary fields and can easily be extended by anyone ;)
# it also ignores TimeZones completely
def htmlToIcs(html):
	allMensen = htmlToDictionary(html)
	retValue = "BEGIN:VCALENDAR\nVERSION:2.0\n"	
	for date, mensen in allMensen.iteritems():
		date = datetime.strptime(date, "%d.%m.%Y")
		for name, meals in mensen.iteritems():
			retValue += "BEGIN:VEVENT\n"
			retValue += "DTSTART:"+datetime.strftime(date,"%Y%m%d")+"T111500\n"
			retValue += "DTEND:"+datetime.strftime(date,"%Y%m%d")+"T140000\n"
			retValue += "SUMMARY:"+name+"\n"
			retValue += "DESCRIPTION:"
			for meal in meals:
				retValue += meal+"\\n"
			retValue += "\nEND:VEVENT\n"
	retValue += "END:VCALENDAR"
	return retValue
	
# Take the HTML Code of the Mensa page and transforms it into json code so that further
# services can easily process it
def htmlToJSON(html):
	allMensen = htmlToDictionary(html)
	return json.dumps(allMensen)