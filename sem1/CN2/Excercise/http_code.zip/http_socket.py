#!/usr/bin/python
import socket
from http_exercise_utils import *
import re
reload(sys)
sys.setdefaultencoding("utf-8")
#create an INET, STREAMing socket
s = socket.socket(
    socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
#now connect to the web server on port 80
# - the normal http port
s.connect(("www.studentenwerkdarmstadt.de", 80))
#send the request (HTTP 1.0 as it does not support chunked transfer encoding)
request = "GET /index.php/de/essen-und-trinken/speisekarten/stadtmitte?ansicht=week HTTP/1.0\nHost: www.studentenwerkdarmstadt.de\n\n"
s.send(request)
#receive the data
data = ""
while True:
    buf = s.recv(1024)
    if not len(buf):
        break
    data += buf
print(htmlToText(data))
#afterwards close the socket
s.shutdown(1)
s.close()
