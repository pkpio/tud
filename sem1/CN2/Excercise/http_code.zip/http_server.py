#!/usr/bin/python
import socket
import re
import urllib2
from http_exercise_utils import *
reload(sys)
sys.setdefaultencoding("utf-8")
# define the error result
error = "HTTP/1.1 404 Not Found\n\n"
# open a socket
s =  socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('', 8080))
while True:
  try:
    s.listen(1)
    conn, addr = s.accept()
    # get some data
    data = conn.recv(1024)
    string = bytes.decode(data)
    # check for correct get command
    correct_get = re.compile(r'GET /mensa\.((ics)|(html)|(json)) HTTP/1\.1')
    reply = ""
    if correct_get.search(string) is not None:
      # deliver the correct content
      header = "HTTP/1.1 200 OK"
      html = urllib2.urlopen('http://www.studentenwerkdarmstadt.de/index.php/de/essen-und-trinken/speisekarten/stadtmitte?ansicht=week').read()
      if "/mensa.ics" in string:
        header += "Content-Type: text/calendar; charset=utf-8\n\n"
        reply = header+htmlToIcs(html)
      elif "/mensa.json" in string:
        header += "Content-Type: application/json; charset=utf-8\n\n"
        reply = header+htmlToJSON(html)
      elif "/mensa.html" in string:
        header += "Content-Type: text/html; charset=utf-8\n\n"
        reply = header+html
      else:
        reply = error #should not be possible
    else:
      reply = error
    conn.send(reply)
    conn.close()
  # on strg+c close the socket
  except KeyboardInterrupt:
    s.shutdown(1)
    s.close()
    sys.exit()