package cart.server.common;

public class Params {
	public static final String API_REST_URI = "http://localhost:8080/rest";
	public static final String API_SOAP_URI = "http://localhost:8090/soap";
}