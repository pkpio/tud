# java-cart
A simple web cart using java SOAP and REST APIs

# Running
1. Server : Go to server folder and run ```ant default```
2. Client : Go to client folder and run ```ant default```
