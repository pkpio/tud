# fly-hunting
Multi-player Fly Hunting Game using Java RMI and Swing

# Running the game
- Execute ```ant run``` in terminal or command prompt
- Pick a name and hit start`

# License
Licensed under [GNU GPL v3][gpl3]

[gpl3]: http://www.gnu.org/licenses/gpl-3.0.en.html
