# pubsub-microblog
A micro blog using PubSub 

# Running
1. Start Apache ActiveMQ broker
2. Run ```ant default```
